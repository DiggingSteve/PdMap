﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DevExpress.Xpo;
using Longjin.Model;
using Longjin.Model.ApiModel;
using Newtonsoft.Json;

namespace PdMap.Web.Map
{
    public partial class DoAction : BasePage
    {
        public void GetTruckAndConstruction()
        {
            IQueryable<TruckGroup> truckCol = new XPQuery<TruckGroup>(DBSession);
            truckCol = truckCol.Where(t => t.GaodeLat>30.40&&t.GaodeLat<31.53&&t.GaodeLong<122.12&&t.GaodeLong>121.20);//过滤空的坐标

            List<TruckGroup> truckLst = truckCol.ToList();

            IQueryable<ConstructionSite> constructionCol = new XPQuery<ConstructionSite>(DBSession);
            constructionCol = constructionCol.Where(t => t.GaodeLat > 30.40 && t.GaodeLat < 31.53 && t.GaodeLong < 122.12 && t.GaodeLong > 121.20);//过滤空的坐标

            List<ConstructionSite> constructionLst = constructionCol.ToList();

            List<MapLayer> layerLst = new List<MapLayer>();
            foreach (var item in constructionLst)
            {
                string layerType = item.PointType;
                if (layerType == "未验") continue;
                MapLayer layer = layerLst.Find(delegate (MapLayer p) { return p.Key == layerType; });
                if (layer == null)
                {
                    layer = new MapLayer(layerType, "construction");
                    layerLst.Add(layer);
                }
                layer.Points.Add(item.Clone());
            }
            foreach (var item in truckLst)
            {
                string layerType = item.PointType;
                MapLayer layer = layerLst.Find(delegate (MapLayer p) { return p.Key ==layerType; });
                if (layer == null)
                {
                    layer = new MapLayer(layerType, "truck");
                    layerLst.Add(layer);
                }
                layer.Points.Add(item.Clone());
            }
            Response.Write(JsonConvert.SerializeObject(layerLst));
        }


    }
}