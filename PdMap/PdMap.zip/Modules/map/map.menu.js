﻿/// <reference path="c:\users\longjin\documents\visual studio 2015\Projects\PdMap\PdMap\js/seajs/sea.js" />

define(function (require, exports, moudles) {
    exports.init = function () {

    };
    exports.loadEvent = function () {

    };
    exports.legendBtnEvent = function (id) {
        $(id).click(function () {
            $(".legend_wrap").css("top","10px");
        });
        $(".legend_wrap .close").click(function () {
            $(".legend_wrap").css("top", "-300px");
        });
    }
});